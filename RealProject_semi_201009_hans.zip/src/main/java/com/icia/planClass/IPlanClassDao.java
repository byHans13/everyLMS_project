package com.icia.planClass;

import com.icia.classup.ClassUpBean;

public interface IPlanClassDao {
	
	
	boolean insertplanclass(ClassUpBean cb);

	boolean updateplanclass(ClassUpBean cub);



}
