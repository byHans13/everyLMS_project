package com.icia.admiapplication;

import lombok.Data;
import lombok.experimental.Accessors;



@Data
@Accessors(chain = true)
public class AdmiapplicationBean {
	
	String aa_idnum;
	Integer aa_lv;
	String aa_id;

}
